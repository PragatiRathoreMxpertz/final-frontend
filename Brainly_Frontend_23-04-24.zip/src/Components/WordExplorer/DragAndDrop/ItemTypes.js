// export const ItemTypes = {
//     FOOD: 'food',
//     GLASS: 'glass',
//     PAPER: 'paper',
//   }

// export const ItemTypes = {
//     ANSWER: 'answer',
//   };


export const ItemTypes = {
  ONE: 'one',
  TWO: 'two',
  THREE: 'three',
  FOUR: 'four',
  FIVE: 'five',
  SIX: 'six',
  SEVEN: 'seven',
  EIGHT: 'eight',
  NINE: 'nine',
  TEN: 'ten'
}